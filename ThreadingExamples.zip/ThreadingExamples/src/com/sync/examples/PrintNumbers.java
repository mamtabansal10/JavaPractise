package com.sync.examples;

public class PrintNumbers implements Runnable{
	
	public void run() {
		prnitValues();
	}
	
	public synchronized void prnitValues() {
		   for (int i=0 ; i<=5; i++) {
			   System.out.println("child thread :"+Thread.currentThread().getName()+
					   " value is :"+i*2);
		   }
		}
	
}