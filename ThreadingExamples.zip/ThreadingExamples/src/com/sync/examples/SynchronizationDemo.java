package com.sync.examples;

public class SynchronizationDemo {
	

	public static void main(String[] args) {
		PrintNumbers pn =  new PrintNumbers();
		
		
		//using  same object
		Thread t1 = new Thread(pn);
		t1.start();
		 
		Thread t2 = new Thread(pn);
		t2.start();
//		
//		Thread t3 = new Thread(pn);
//		t3.start();
		
	
		//using different object
//		PrintNumbers pn1 =  new PrintNumbers();
////		Thread t5 = new Thread(pn1);
////		t5.start();
////		
//		Thread t4 = new Thread(pn1);
//		t4.start();
		


	}

}
