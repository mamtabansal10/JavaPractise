package com.threading.examples;

public class ThreadExample extends Thread {

	public static void main(String[] args) {
		ThreadExample t = new ThreadExample();
		t.start();
	}

	@Override
	public void run() {
		System.out.println("Thread task");
	}

}
