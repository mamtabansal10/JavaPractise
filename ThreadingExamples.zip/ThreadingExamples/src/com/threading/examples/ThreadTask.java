package com.threading.examples;

public class ThreadTask implements Runnable {
	
	public void run() {
		System.out.println("threading task");
		System.out.println("Thread task executed by : "+Thread.currentThread().getName());
		Thread.currentThread().setName("Mamta");
		System.out.println("New name : "+Thread.currentThread().getName());
		for(int i=1; i<=5; i++) {
			try {
				//Thread.sleep(-1000);
				Thread.sleep(1000);
				System.out.println(i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}

}
