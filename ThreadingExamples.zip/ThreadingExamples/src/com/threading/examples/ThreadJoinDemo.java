package com.threading.examples;

public class ThreadJoinDemo implements Runnable {

	@Override
	public void run() {
		
//		try {
//			Test.mainThread.join();
//		} catch (InterruptedException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
		
		System.out.println("Execution child thread task");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("child thread task completed");
		
	}
	
	
	

}
