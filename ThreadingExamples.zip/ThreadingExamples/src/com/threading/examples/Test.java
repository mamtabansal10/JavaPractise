package com.threading.examples;

public class Test {
	
	static Thread mainThread;

	public static void main(String[] args) throws InterruptedException {
		
		mainThread = Thread.currentThread();
		Thread t = new Thread(new ThreadTask());
		t.start();
		System.out.println("main class thread Name :"+Thread.currentThread().getName());
		System.out.println("thread task alive status : "+t.isAlive());
		System.out.println("main thread alive status : "+Thread.currentThread().isAlive());
		System.out.println(t.getPriority());
		System.out.println("main thread prority is : "+Thread.currentThread().getPriority());
		t.setPriority(Thread.MIN_PRIORITY);
		System.out.println("child thread priority is :"+t.getPriority());
		
		Thread.sleep(6000);
		
		Thread tj = new Thread(new ThreadJoinDemo());
		tj.start();
		t.join();
		tj.join();
		
		System.out.println("main thread task started");
		Thread.sleep(1000);
		System.out.println("main thread task completed");
		
		Thread tmd = new Thread(new ThreadMethodsDemo());
		tmd.start();
		//tmd.interrupt();
	}
		
}
