import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

public class ReadJsonExample {
    public static void main(String[] args)  {

        try {
            Object obj = new JSONParser().parse(new FileReader("src\\test\\resources\\test.json"));

            JSONObject jsonObject = (JSONObject)obj;
            String firstName = (String) jsonObject.get("firstName");
            String lastName = (String) jsonObject.get("lastName");

            System.out.println(firstName);
            System.out.println(lastName);

            JSONArray phoneNumbers = (JSONArray) jsonObject.get("phoneNumbers");
            Iterator itr =  phoneNumbers.iterator();
            while(itr.hasNext()){
                Iterator<Map.Entry>itr1 = ((Map) itr.next()).entrySet().iterator();
                while (itr1.hasNext()) {
                    Map.Entry pair = itr1.next();
                    System.out.println(pair.getKey() + " : " + pair.getValue());
                }
//                System.out.println(itr.next());
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
