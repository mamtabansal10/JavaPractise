package om.design.util;

public class NotificationFactory {

	public Notification getInstance(String str) {

		switch (str) {

		case "SMS":
			return new SMSNotification();
		case "Email":
			return new EmailNotification();
		case "Call":
			return new CallNotification();
		default:
			System.out.println("please select approriate notification type");

		}

		return null;

	}

}
