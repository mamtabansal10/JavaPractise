package om.design.util;

public class CallNotification implements Notification{

	@Override
	public void notifyUser() {
		
		System.out.println("call user");
		
	}

}
