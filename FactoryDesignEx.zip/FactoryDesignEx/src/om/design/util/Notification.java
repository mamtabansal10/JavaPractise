package om.design.util;

public interface Notification {
	
	public void notifyUser();


}
