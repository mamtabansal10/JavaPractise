package com.design.factory;

import om.design.util.Notification;
import om.design.util.NotificationFactory;

public class FactoryMain {

	public static void main(String[] args) {

		NotificationFactory nf = new NotificationFactory();
		Notification notify = nf.getInstance("Call");
		notify.notifyUser();

	}

}
